import requests

PROFILES = {
    "driving": "driving",
    "walking": "foot",
    "cycling": "bike"
}
OSRM_URL = "https://router.project-osrm.org/route/v1"

def get_route(start, end, mode="driving"):
    profile = PROFILES.get(mode, "driving")
    url = f"{OSRM_URL}/{profile}/{start['lon']},{start['lat']};{end['lon']},{end['lat']}"
    response = requests.get(
        url,
        params={"overview": "full", "geometries": "geojson", "steps": "false"},
        timeout=20
    )
    response.raise_for_status()
    data = response.json()

    if data.get("code") != "Ok" or not data.get("routes"):
        raise RuntimeError("No route found for the selected locations.")

    route = data["routes"][0]
    return {
        "distance_km": round(route["distance"] / 1000, 2),
        "duration_minutes": round(route["duration"] / 60, 1),
        "geometry": route["geometry"]
    }
